﻿using Volo.Abp.AspNetCore.Mvc.Authentication;

namespace MyCompanyName.MyProjectName.Blazor.Server.Tiered.Controllers;

public class AccountController : ChallengeAccountController
{

}
