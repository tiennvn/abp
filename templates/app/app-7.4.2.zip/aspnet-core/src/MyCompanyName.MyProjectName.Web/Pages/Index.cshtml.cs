﻿namespace MyCompanyName.MyProjectName.Web.Pages;

public class IndexModel : MyProjectNamePageModel
{
    public void OnGet()
    {

    }
}
