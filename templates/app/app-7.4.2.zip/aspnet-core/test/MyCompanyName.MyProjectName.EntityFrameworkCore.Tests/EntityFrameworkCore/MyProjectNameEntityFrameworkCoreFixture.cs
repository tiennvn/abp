using System;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

public class MyProjectNameEntityFrameworkCoreFixture : IDisposable
{
    public void Dispose()
    {

    }
}
