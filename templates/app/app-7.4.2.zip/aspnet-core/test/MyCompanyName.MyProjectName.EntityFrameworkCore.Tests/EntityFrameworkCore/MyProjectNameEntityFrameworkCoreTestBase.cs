﻿using Volo.Abp;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore;

public abstract class MyProjectNameEntityFrameworkCoreTestBase : MyProjectNameTestBase<MyProjectNameEntityFrameworkCoreTestModule>
{

}
