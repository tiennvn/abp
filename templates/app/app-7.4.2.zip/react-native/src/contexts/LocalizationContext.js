import React from 'react';

export const LocalizationContext = React.createContext();
